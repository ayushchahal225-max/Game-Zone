GAMEZONE — पहला संस्करण

1. index.html पर डबल-क्लिक करके वेबसाइट ब्राउज़र में खोलें।
2. Games के नाम बदलने के लिए index.html में cards edit करें।
3. आगे चाहें तो इसमें असली game links, login, leaderboard, images और online hosting जोड़ सकते हैं।
